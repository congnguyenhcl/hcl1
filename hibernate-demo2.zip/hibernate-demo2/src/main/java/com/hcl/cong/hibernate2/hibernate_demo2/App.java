package com.hcl.cong.hibernate2.hibernate_demo2;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


public class App {
	public static void main(String[] args) {
		// Generate a new hibernate configuration object
		Configuration hibernateCfg = new Configuration();

		// Configure the hibernate configuration using a xml file
		hibernateCfg = hibernateCfg.configure("META-INF/hibernate.cfg.xml");

		// Create and bind a session factory to the new hib cfg object
		SessionFactory sessionFactory = hibernateCfg.buildSessionFactory();

		// Open the session factory
		Session session = sessionFactory.openSession();
		// The id will be ignored because the hib cfg specifies it is a generated column
		Student s1 = new Student(1121, "Peter", "Holland", "Junior");
		Student s2 = new Student(1121, "Bruce", "Brenner", "Senior");
		
		Teacher t1 = new Teacher(1234,"Justin", "Bieber", "Sophmore");
		Teacher t2 = new Teacher(3456,"Arnold", "Schwarzenegger", "Freshman");

		Transaction transaction = session.beginTransaction();

		session.save(s1);
		session.save(s2);
		session.save(t1);
		session.save(t2);

		transaction.commit();

		session.close();
		sessionFactory.close();
	}
}
