package b;

import a.A;

class B extends A {
	void m4() {
		m3();
	}
}

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A a = new A();
		System.out.println(a.a);

//	System.out.println(a.b); //b is default and cannot be accessed from another package
//	System.out.println(a.c); //c is private and can only be access from class A
//	a.m2(); //m2 is private and can only be accessed from class A
//	a.m3(); //m3 is protected and can only be accessed from A subclass

		B b = new B();
		b.m4(); 
	}
}
