package a;
public class A {
	public int a = 10;
	int b = 20;
	private int c = 30;
	
	public void m1(){
		System.out.println("public m1 method of class A");
	}
	private void m2() {
		System.out.println("private m2 method of class A");
	}
	protected void m3() {
		System.out.println("protected m3 method of class A");
	}
}


